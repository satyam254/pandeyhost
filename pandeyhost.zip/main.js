function nav5() {

    document.getElementById('toggle_id').style.display = "none";
    document.getElementById("toggle_id2").style.display = "none";
    document.getElementById("toggle_id3").style.display = "none";
    document.getElementById("toggle_id4").style.display = "none";
}


var t = true;

function nav4() {
    document.getElementById('toggle_id').style.display = "none";
    document.getElementById("toggle_id2").style.display = "none";
    document.getElementById("toggle_id3").style.display = "none";
    let toggle_id4 = document.getElementById('toggle_id4');
    if (toggle_id4.style.display === "block") {
        toggle_id4.style.display = "none";
    } else {
        toggle_id4.style.display = "block";
    }

    if (t == true) {
        arrowicon2 = document.getElementById('arrowicon4.1');
        arrowicon2.style.display = 'block';
        arrowicon1 = document.getElementById('arrowicon4').style.display = 'none';
        t = false;
    }
    else {
        arrowicon1 = document.getElementById('arrowicon4');
        arrowicon1.style.display = 'block';
        arrowicon2 = document.getElementById('arrowicon4.1').style.display = 'none';
        t = true;
    }

}
var a = true;

function nav3() {
    document.getElementById('toggle_id').style.display = "none";
    document.getElementById("toggle_id4").style.display = "none";

    document.getElementById("toggle_id2").style.display = "none";
    let toggle_id3 = document.getElementById('toggle_id3');
    if (toggle_id3.style.display === "block") {
        toggle_id3.style.display = "none";
    } else {
        toggle_id3.style.display = "block";
    }

    if (a == true) {
        arrowicon2 = document.getElementById('arrowicon3.1');
        arrowicon2.style.display = 'block';
        arrowicon1 = document.getElementById('arrowicon3').style.display = 'none';
        a = false;
    }
    else {
        arrowicon1 = document.getElementById('arrowicon3');
        arrowicon1.style.display = 'block';
        arrowicon2 = document.getElementById('arrowicon3.1').style.display = 'none';
        a = true;

    }

}


var s = true;

function nav1() {
    document.getElementById("toggle_id2").style.display = "none";
    document.getElementById("toggle_id3").style.display = "none";
    document.getElementById("toggle_id4").style.display = "none";

    let toggle_id = document.getElementById('toggle_id');
    if (toggle_id.style.display === "block") {
        toggle_id.style.display = "none";
    } else {
        toggle_id.style.display = "block";
    }

    if (s == true) {
        arrowicon2 = document.getElementById('arrowicon2');
        arrowicon2.style.display = 'block';
        arrowicon1 = document.getElementById('arrowicon1').style.display = 'none';
        s = false;
    }
    else {
        arrowicon1 = document.getElementById('arrowicon1');
        arrowicon1.style.display = 'block';
        arrowicon2 = document.getElementById('arrowicon2').style.display = 'none';
        s = true;


    }

}

var x = true;
function nav2() {
    document.getElementById('toggle_id').style.display = "none";
    document.getElementById("toggle_id3").style.display = "none";
    document.getElementById("toggle_id4").style.display = "none";



    let toggle_id2 = document.getElementById("toggle_id2");

    if (toggle_id2.style.display === "block") {
        toggle_id2.style.display = "none";

    } else {
        toggle_id2.style.display = "block";
    }

    if (x == true) {
        arrowicon2 = document.getElementById('arrowicon2.2');
        arrowicon2.style.display = 'block';
        arrowicon1 = document.getElementById('arrowicon2.1').style.display = 'none';
        x = false;
    }
    else {
        arrowicon1 = document.getElementById('arrowicon2.1');
        arrowicon1.style.display = 'block';
        arrowicon2 = document.getElementById('arrowicon2.2').style.display = 'none';
        x = true;
    }
}

function getlang() {
    let allLang = document.getElementById('choose_language');
    if (allLang.style.display === "block") {
        allLang.style.display = "none";
        document.getElementById('full_body').style.display = "block";
    } else {
        allLang.style.display = "block";
        document.getElementById('full_body').style.display = "none";
    }
}


function cut() {

    document.getElementById('choose_language').style.display = "none";
    document.getElementById('full_body').style.display = "block";

}

let fullBody = document.getElementById('full_body');
fullBody.addEventListener('click', () => {
    document.getElementById('toggle_id').style.display = "none";
    document.getElementById("toggle_id2").style.display = "none";
    document.getElementById("toggle_id3").style.display = "none";
    document.getElementById("toggle_id4").style.display = "none";
})


function openNav() {
    document.getElementById("mySidenav").style.width = "100%";
}

function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
}


let Hosting = document.getElementById('Hosting');
Hosting.addEventListener('click', () => {
    let hover_Drop = document.getElementById("hover_Drop");
    if (hover_Drop.style.display === "block") {
        hover_Drop.style.display = "none";
    } else {
        hover_Drop.style.display = "block";
    }
})
let Hosting2 = document.getElementById('Hosting2');
Hosting2.addEventListener('click', () => {
    let hover_Drop2 = document.getElementById("hover_Drop2");
    if (hover_Drop2.style.display === "block") {
        hover_Drop2.style.display = "none";
    } else {
        hover_Drop2.style.display = "block";
    }
})
let Hosting3 = document.getElementById('Hosting3');
Hosting3.addEventListener('click', () => {
    let hover_Drop3 = document.getElementById("hover_Drop3");
    if (hover_Drop3.style.display === "block") {
        hover_Drop3.style.display = "none";
    } else {
        hover_Drop3.style.display = "block";
    }
})




var deadline = new Date("sept 25, 2022 17:46:25").getTime();

var x = setInterval(function () {

    var now = new Date().getTime();
    var t = deadline - now;
    var days = Math.floor(t / (1000 * 60 * 60 * 24));
    var hours = Math.floor((t % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    var minutes = Math.floor((t % (1000 * 60 * 60)) / (1000 * 60));
    var seconds = Math.floor((t % (1000 * 60)) / 1000);
    document.getElementById("day").innerHTML = days;
    document.getElementById("hour").innerHTML = hours;
    document.getElementById("minute").innerHTML = minutes;
    document.getElementById("second").innerHTML = seconds;
    if (t < 0) {
        clearInterval(x);
        document.getElementById("demo").innerHTML = "TIME UP";
        document.getElementById("day").innerHTML = '0';
        document.getElementById("hour").innerHTML = '0';
        document.getElementById("minute").innerHTML = '0';
        document.getElementById("second").innerHTML = '0';
    }
}, 1000);




// owl crosel

$(document).ready(function () {
    $(".owl-carousel").owlCarousel({
        loop: true,
        margin: 10,
        nav: true,
        autoplay: true,
        autoplayTimeout: 3000,
        autoplayHoverPause: true,
        center: true,
        navText: [
            "<i class='fa fa-angle-left'></i>",
            "<i class='fa fa-angle-right'></i>"
        ],
        responsive: {
            0: {
                items: 1
            },
            600: {
                items: 1
            },
            1000: {
                items: 3
            }
        }
    });
});








var coll = document.getElementsByClassName("collapsible");
var i;

for (i = 0; i < coll.length; i++) {
    coll[i].addEventListener("click", function () {
        this.classList.toggle("activee");
        var content = this.nextElementSibling;
        if (content.style.maxHeight) {
            content.style.maxHeight = null;
        } else {
            content.style.maxHeight = content.scrollHeight + "px";
        }
    });
}




function changeImage() {
    var image = document.getElementById('plus');
    if (image.src.match("minus")) {
        image.src = "plus.png";
    } else {
        image.src = "minus.png";
    }
}
function changeImage2() {
    var image = document.getElementById('plus2');
    if (image.src.match("minus")) {
        image.src = "plus.png";
    } else {
        image.src = "minus.png";
    }
}
function changeImage3() {
    var image = document.getElementById('plus3');
    if (image.src.match("minus")) {
        image.src = "plus.png";
    } else {
        image.src = "minus.png";
    }
}
function changeImage4() {
    var image = document.getElementById('plus4');
    if (image.src.match("minus")) {
        image.src = "plus.png";
    } else {
        image.src = "minus.png";
    }
}
function changeImage5() {
    var image = document.getElementById('plus5');
    if (image.src.match("minus")) {
        image.src = "plus.png";
    } else {
        image.src = "minus.png";
    }
}
function changeImage6() {
    var image = document.getElementById('plus6');
    if (image.src.match("minus")) {
        image.src = "plus.png";
    } else {
        image.src = "minus.png";
    }
}
function changeImage7() {
    var image = document.getElementById('plus7');
    if (image.src.match("minus")) {
        image.src = "plus.png";
    } else {
        image.src = "minus.png";
    }
}
function changeImage8() {
    var image = document.getElementById('plus8');
    if (image.src.match("minus")) {
        image.src = "plus.png";
    } else {
        image.src = "minus.png";
    }
}
function changeImage9() {
    var image = document.getElementById('plus9');
    if (image.src.match("minus")) {
        image.src = "plus.png";
    } else {
        image.src = "minus.png";
    }
}
function changeImage10() {
    var image = document.getElementById('plus10');
    if (image.src.match("minus")) {
        image.src = "plus.png";
    } else {
        image.src = "minus.png";
    }
}
function changeImage11() {
    var image = document.getElementById('plus11');
    if (image.src.match("minus")) {
        image.src = "plus.png";
    } else {
        image.src = "minus.png";
    }
}
function changeImage12() {
    var image = document.getElementById('plus12');
    if (image.src.match("minus")) {
        image.src = "plus.png";
    } else {
        image.src = "minus.png";
    }
}




var coll = document.getElementsByClassName("satym");
var i;

for (i = 0; i < coll.length; i++) {
    coll[i].addEventListener("click", function () {
        this.classList.toggle("active");
        var content = this.nextElementSibling;
        if (content.style.display === "block") {
            content.style.display = "none";
        } else {
            content.style.display = "block";
        }
    });
}


function footerTgl() {
    var image = document.getElementById('tgl1');
    if (image.src.match("minus")) {
        image.src = "plus.png";
    } else {
        image.src = "minus.png";
    }
}
function footerTgl2() {
    var image = document.getElementById('tgl2');
    if (image.src.match("minus")) {
        image.src = "plus.png";
    } else {
        image.src = "minus.png";
    }
}
function footerTgl3() {
    var image = document.getElementById('tgl3');
    if (image.src.match("minus")) {
        image.src = "plus.png";
    } else {
        image.src = "minus.png";
    }
}
function footerTgl4() {
    var image = document.getElementById('tgl4');
    if (image.src.match("minus")) {
        image.src = "plus.png";
    } else {
        image.src = "minus.png";
    }
}


let Unmatched = document.getElementById("Unmatched");
        Unmatched.addEventListener('click', () => {
            document.getElementById("change_heading").innerText = "Unmatched Performance";
            document.getElementById('change-para').innerText = "We care about the performance of your website. That's why we employ cutting-edge technology from HTTP/3 and IPv6 to LiteSpeed web servers and CDNs to power your website. All Premium and Business plans include unmetered bandwidth, so you won't have to worry about your website's speed.";

        })


        let Security = document.getElementById("Security");
        Security.addEventListener('click', () => {
            document.getElementById("change_heading").innerText = "TOTAL SECURITY";
            document.getElementById('change-para').innerText = "Your web server security is very important to us. You can rest assured that your website will be secure thanks to CloudLinux and LVE containerized environment, comprehensive DDoS protection, automated website backups, auto-updates, in-house WAF, and other security features. In addition, all Premium and Business web hosting plans include a free SSL certificate for extra site protection.";
        })

        let Complete = document.getElementById("Complete");
        Complete.addEventListener('click', () => {
            document.getElementById("change_heading").innerText = "COMPLETE CONTROL";
            document.getElementById('change-para').innerText = "You don't have to worry about compromising your code or website with Hostinger. Whether you're trying out different PHP versions or looking for ways to optimize your databases, chances are we've got you covered. SSH, WP-CLI, PHP version control, Git integration, MySQL management, and more tools are available to keep you in control of your shared servers.";
        })

        let Global = document.getElementById("Global");
        Global.addEventListener('click', () => {
            document.getElementById("change_heading").innerText = "GLOBAL DATA CENTERS";
            document.getElementById('change-para').innerHTML = "Looking for the best hosting in India with local data centres? We've got your back. Here are the locations of our data centres:<br><br><ul><li>Europe (the Netherlands, Lithuania, the United Kingdom)</li><li>Asia (Singapore, India</li><li>North America (the USA)</li><li>South America (Brazil)</li></ul>We also provide self-service data centre location changes. Once a month, you can switch your data centre location for faster website loading for your visitors.";
        })
        let Managed = document.getElementById("Managed");
        Managed.addEventListener('click', () => {
            document.getElementById("change_heading").innerText = "MANAGED WORDPRESS";
            document.getElementById('change-para').innerHTML = "Our managed WordPress hosting comes with ready-to-use features, so you can start building your website right away. Enjoy our user-friendly control panel, 1-click installer, and automatic WordPress patches. In addition, get pre-installed WordPress performance plugins and marketing tools to grow your online presence.";
        })

        let WordPress = document.getElementById("WordPress");
        WordPress.addEventListener('click', () => {
            document.getElementById("change_heading").innerText = "WORDPRESS STAGING";
            document.getElementById('change-para').innerHTML = "Our hosting plans include the WordPress staging environment. As a result, you can create a copy of your website and experiment with alternative layouts, content, and plugins, only publishing your changes when you're ready.";
        })